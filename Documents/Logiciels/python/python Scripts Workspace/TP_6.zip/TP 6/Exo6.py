# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:57:12 2019

@author: johna
"""

chiffreAConvertir = 28
tableau_correspondance = {1:"I",2:"II",3:"III",4:"V",5:"V",7:"VII",8:"VIII",9:"IV",10:"X",50:"L",100:"C",500:"D",1000:"M"}

while (chiffreAConvertir > 0):
    for current_correspondance in tableau_correspondance :
        chiffreAConvertir =3