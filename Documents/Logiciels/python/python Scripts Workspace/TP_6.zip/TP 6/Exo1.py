# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 09:21:59 2019

@author: johna
"""
import math
# Formule : V = π x 3² x 6 / 3 ≈ 56,55 cm³
print("Veuillez entrer un rayon : ")
rayon = input()
print("Veuillez entrer une hauteur : ")
hauteur = input()
if(rayon.isdigit() & hauteur.isdigit()):
    resultat = math.pi * (int(rayon)**2) * int(hauteur) / int(rayon)
    print("Volume du cône droit : "+ str(resultat))
else :
    print("Le volume ou la hauteur n'est pas un chiffre")
