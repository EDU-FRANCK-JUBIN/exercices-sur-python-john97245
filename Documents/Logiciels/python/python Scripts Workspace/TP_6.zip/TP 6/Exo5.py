# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:50:32 2019

@author: johna
"""
import math

def MinMaxMoy(liste):
    sum_liste = 0
    for i in range(len(liste)):
        sum_liste += liste[i]
    resultat = "Minimum : "+ str(min(liste))+"\n"
    resultat +="Maximum : "+ str(max(liste))+"\n"
    resultat +="Moyenne : "+ str(sum_liste/2)
    return resultat
print(MinMaxMoy([10,18,14,20,12,16]))