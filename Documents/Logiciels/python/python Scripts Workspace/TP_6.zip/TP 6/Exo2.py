# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 09:41:32 2019

@author: johna
"""

print("Entrez un entier strictement positif : ")
entier_input = input()

if(entier_input.isdigit()):
    entier = int(entier_input)
    resultat = "Diviseurs propres sans répétitions de "+ str(entier) + ": "
    nb_diviseur = 0
    if(entier > 0):
        for i in range(2,entier):
            if(entier %i == 0):
               resultat += str(i)+" "
               nb_diviseur += 1
        if (nb_diviseur != 0):  
            resultat += "(Soit " + str(nb_diviseur) + " diviseurs propres"
            print(resultat)
        else:
            resultat += "aucun ! Il est premier"
            print(resultat)
    else:
        print("erreur : entier négatif")
else:
    print("erreur : veuillez entrer un chiffre")