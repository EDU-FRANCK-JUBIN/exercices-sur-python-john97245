# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:08:32 2019

@author: johna
"""

"""
A FAIRE
"""