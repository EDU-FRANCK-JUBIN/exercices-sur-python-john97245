# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:10:23 2019

@author: johna
"""

# test : attgcaatggtggtacatg
# test 2 : cacacatgtgtg

def valide(saisie):
    correcte = "true"
    for char in saisie :
        if char not in ['a','t','g','c'] :
            correcte = "false"
    return correcte

def saisie():
    print("Veuillez saisir une chaine d'ADN composé uniquement de 'a','t','g' ou 'c': ")
    saisie = input()
    if(valide(saisie) == "true"):
        return saisie
    else :
        exit

def proportion(chaine,sequence):

    len_sequence = len(sequence)
    len_chaine = len(chaine)
    nb_sequence = 0
    for i in range(0, len(chaine)):
        if (chaine[i:i+len_sequence] == sequence):
            nb_sequence += len_sequence   
            
    proportion = nb_sequence*100/len_chaine
    resultat = "chaine : "+ chaine +"\nsequence : "+ sequence + "\nIl y a "+ str(round(proportion,2)) +"% de " + sequence + " dans votre chaine."
    return resultat
print(proportion("cacacatgtgtg","ca"))